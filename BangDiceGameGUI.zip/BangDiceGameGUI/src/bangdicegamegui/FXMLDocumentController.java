/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bangdicegamegui;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import java.util.Arrays;

/**
 *
 * @author torti
 */
public class FXMLDocumentController implements Initializable {
    @FXML private Label StartingGameInstructions;
    @FXML private Label StartPlayers;
    @FXML private Label StartExpansions;
    @FXML private TextField UserPlayers;
    @FXML private TextField UserExpansions;
    @FXML private Button StartGameButton;
    @FXML private Label aPile;
    @FXML private ImageView caPile;
    @FXML private Button rerollDice;
    @FXML private Button finalizeDice;
    @FXML private Button EndTurn;
    @FXML private Label rerollsLeft;
    @FXML private Label Infobox;
    @FXML private Label pTurnL;
    @FXML private Label p0Tag;
    @FXML private Label p1Tag;
    @FXML private Label p2Tag;
    @FXML private Label p3Tag;
    @FXML private Label p4Tag;
    @FXML private Label p5Tag;
    @FXML private Label p6Tag;
    @FXML private Label p7Tag;
    private Label[]pTags=new Label[8];
    @FXML private ImageView p0Pic;
    @FXML private ImageView p1Pic;
    @FXML private ImageView p2Pic;
    @FXML private ImageView p3Pic;
    @FXML private ImageView p4Pic;
    @FXML private ImageView p5Pic;
    @FXML private ImageView p6Pic;
    @FXML private ImageView p7Pic;
    @FXML private ImageView p0cArrow;
    @FXML private ImageView p1cArrow;
    @FXML private ImageView p2cArrow;
    @FXML private ImageView p3cArrow;
    @FXML private ImageView p4cArrow;
    @FXML private ImageView p5cArrow;
    @FXML private ImageView p6cArrow;
    @FXML private ImageView p7cArrow;
    private ImageView[]pcArrows=new ImageView[8];
    private ImageView[]pPics=new ImageView[8];
    @FXML private Button p0Button;
    @FXML private Button p1Button;
    @FXML private Button p2Button;
    @FXML private Button p3Button;
    @FXML private Button p4Button;
    @FXML private Button p5Button;
    @FXML private Button p6Button;
    @FXML private Button p7Button;
    @FXML private Button[]pButtons=new Button[8];
    @FXML private Button d0Switch;
    @FXML private Button d1Switch;
    @FXML private Button d2Switch;
    @FXML private Button d3Switch;
    @FXML private Button d4Switch;
    @FXML private Button[]dSwitch=new Button[5];
    @FXML private Button pCoward;
    @FXML private Button pLoudmouth;
    @FXML private Button pNeither;
    @FXML private Label p0HP;
    @FXML private Label p1HP;
    @FXML private Label p2HP;
    @FXML private Label p3HP;
    @FXML private Label p4HP;
    @FXML private Label p5HP;
    @FXML private Label p6HP;
    @FXML private Label p7HP;
    Label[]pHP=new Label[8];
    @FXML private Label p0Arrows;
    @FXML private Label p1Arrows;
    @FXML private Label p2Arrows;
    @FXML private Label p3Arrows;
    @FXML private Label p4Arrows;
    @FXML private Label p5Arrows;
    @FXML private Label p6Arrows;
    @FXML private Label p7Arrows;
    @FXML private Label[]pArrows=new Label[8];
    @FXML private Label p0Role;
    @FXML private Label p1Role;
    @FXML private Label p2Role;
    @FXML private Label p3Role;
    @FXML private Label p4Role;
    @FXML private Label p5Role;
    @FXML private Label p6Role;
    @FXML private Label p7Role;
    private Label[]pRoles=new Label[8];
    @FXML private Label ZombieHandsL;
    @FXML public ToggleButton d0Button;
    @FXML private ToggleButton d1Button;
    @FXML private ToggleButton d2Button;
    @FXML private ToggleButton d3Button;
    @FXML private ToggleButton d4Button;
    private ToggleButton[]dButtons=new ToggleButton[5];
    @FXML private ImageView d0Pic;
    @FXML private ImageView d1Pic;
    @FXML private ImageView d2Pic;
    @FXML private ImageView d3Pic;
    @FXML private ImageView d4Pic;
    private ImageView[]dPics=new ImageView[5];
    private int ZombieHands;
    private boolean expansions;
    private int PlayerCount;
    private int ArrowPile;
    private int rCount;
    private int oCount;
    private int pAlive;
    private int pSheriff;
    private int pcArrow;
    private int pTurn;
    private int uType;
    private int uRerolls;
    private int uGatlingCount;
    private int uDynamiteCount;
    private int uActionCount;
    private int uAction;
    private int pZombies;
    private boolean Outbreak;
    private int pZombieMaster;
    private int[]BoneyardCards=new int[11];
    private int[]uRolls=new int[5];
    public int[][]player_info=new int[5][8];
    GUIControl GUIControl=new GUIControl();
    player_manipulation pmanip=new player_manipulation();
    dice_actions dice=new dice_actions();
    AI ai=new AI();
    user_turn user=new user_turn();
    Initialization initialize=new Initialization();
    
    @FXML public void StartGameAction() {
        if(UserExpansions.getText().equals("Yes") || UserExpansions.getText().equals("yes")){
            expansions=true;
            if(Integer.parseInt(UserPlayers.getText())>=3 && Integer.parseInt(UserPlayers.getText())<=7){
                PlayerCount=Integer.parseInt(UserPlayers.getText())+1;
                GUIControl.StartDisappear();
                GUIControl.GameAppear();
                initialize.game(expansions);
            }
            else{
                StartingGameInstructions.setText("Enter either Yes or No in the goddamn textfield next to expansions      Enter a number between 3 and 7 next to players");
            }
        }
        else if(UserExpansions.getText().equals("No") || UserExpansions.getText().equals("no")){
            expansions=false;
            if(Integer.parseInt(UserPlayers.getText())>=3 && Integer.parseInt(UserPlayers.getText())<=7){
                PlayerCount=Integer.parseInt(UserPlayers.getText())+1;
                GUIControl.StartDisappear();
                GUIControl.GameAppear();
                initialize.game();
            }
            else{
                StartingGameInstructions.setText("Enter either Yes or No next to expansions      Enter a number between 3 and 7 next to players");
            }
        }
        else{
            StartingGameInstructions.setText("Enter either Yes or No next to Expansions      Enter a number between 3 and 7 next to players");
        }
    }
    @FXML public void rerollDiceAction(){
        if(uRerolls>0){
            uDynamiteCount=0;
            boolean[]rerolls=new boolean[5];
            for(int i=0;i<5;i++){
                if(dButtons[i].isSelected()){
                    dButtons[i].setSelected(false);
                    dButtons[i].setOpacity(0);
                    rerolls[i]=true;
                }
                else{
                    rerolls[i]=false;
                }
            }
            if(!expansions){
                dice.reroll(uRolls,rerolls);                
            }
            else{
                dice.reroll(uRolls,rerolls,expansions);
            }
            if(expansions){
                for(int i=0;i<5;i++){
                    if(uRolls[i]==0 || uRolls[i]==10 || uRolls[i]==16 || uRolls[i]==22){
                        if(pcArrow==-1){
                            dSwitch[i].setVisible(true);
                            dSwitch[i].setDisable(false);
                        }
                    }
                }
            }
            for(int i=0;i<5;i++){
                if((uRolls[i]==1 || uRolls[i]==6 || uRolls[i]==12 || uRolls[i]==18) && player_info[0][0]!=1){
                    dButtons[i].setStyle("-fx-background-color: RED");
                    dButtons[i].setOpacity(0.333);
                    dButtons[i].setDisable(true);
                    uDynamiteCount+=1;
                }
                else if(uRolls[i]==0 || uRolls[i]==10 || uRolls[i]==16 || uRolls[i]==22){
                    if(!expansions){
                        dice.arrows(0);
                        uRolls[i]=-1;
                    }
                    else{
                        dice.arrows(0,expansions);
                        uRolls[i]=-2;
                    }
                }
            }
            if(uDynamiteCount>=3){
                finalizeDiceAction();
            }
            uRerolls-=1;
            rerollsLeft.setText("Rerolls Left: "+uRerolls);
            if(uRerolls==0){
                rerollDice.setVisible(false);
                rerollDice.setDisable(true);
            }
        }
        else{
            Infobox.setText(Infobox.getText()+"No more rerolls left\n");
        }
    }
    @FXML public void finalizeDiceAction(){
        rerollsLeft.setVisible(false);
        if(!expansions){
            uActionCount=0;
            uGatlingCount=0;
            int shot1shot2Count=0;
            Arrays.sort(uRolls);
            for(int i=0;i<5;i++){
                if(uRolls[i]==2 || uRolls[i]==3 || uRolls[i]==4){
                    uActionCount+=1;
                    if(uRolls[i]==2 || uRolls[i]==3){
                        shot1shot2Count+=1;
                    }
                }
                else if(uRolls[i]==5){
                    uGatlingCount+=1;
                }
            }
            if(player_info[0][0]==5 && shot1shot2Count==0){
                dice.beer(0);
                dice.beer(0);
                Infobox.setText("Player uses Suzy Lafayette ability to heal for 2(beers above are for that)");
            }
            if(uDynamiteCount>=3 && uActionCount==0){
                dice.dynamite(0);
                finalizeDice.setVisible(false);
                rerollDice.setVisible(false);
                EndTurn.setVisible(true);
                EndTurn.setDisable(false);
                rerollsLeft.setVisible(false);
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
                for(int i=0;i<5;i++){
                    dButtons[i].setVisible(false);
                    dButtons[i].setOpacity(0);
                }
            }
            else if(uDynamiteCount>=3){
                dice.dynamite(0);
            }
            if(uGatlingCount>=3 && uActionCount==0){
                dice.gatling(0);
                finalizeDice.setVisible(false);
                rerollDice.setVisible(false);
                EndTurn.setVisible(true);
                EndTurn.setDisable(false);
                rerollsLeft.setVisible(false);
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
                for(int i=0;i<5;i++){
                    dButtons[i].setVisible(false);
                    dButtons[i].setOpacity(0);
                }
            }
            if(uActionCount>0){
                user.Action();
            }
            else{
                finalizeDice.setVisible(false);
                rerollDice.setVisible(false);
                EndTurn.setVisible(true);
                EndTurn.setDisable(false);
                rerollsLeft.setVisible(false);
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
                for(int i=0;i<5;i++){
                    dButtons[i].setVisible(false);
                    dButtons[i].setOpacity(0);
                }
            }
        }
        if(expansions){
            if(player_info[0][0]==10){
                for(int i=0;i<5;i++){
                    if(uRolls[i]==0 || uRolls[i]==10 || uRolls[i]==16 || uRolls[i]==22){
                        dice.arrows(0,expansions);
                    }
                }
            }
            for(int i=0;i<5;i++){
                if(uRolls[i]==19){
                    dice.beer(0);
                }
            }
            uDynamiteCount=0;
            for(int i=0;i<5;i++){
                if(uRolls[i]==1 || uRolls[i]==6 || uRolls[i]==12 || uRolls[i]==18){
                    uDynamiteCount+=1;
                    uRolls[i]=-1;
                }
            }
            if(uDynamiteCount>=3){
                dice.dynamite(0);
            }
            uGatlingCount=0;
            for(int i=0;i<5;i++){
                if(uRolls[i]==5 || uRolls[i]==21){
                    uGatlingCount+=1;
                    uRolls[i]=-1;
                }
                else if(uRolls[i]==11){
                    uGatlingCount+=2;
                }
            }
            for(int i=0;i<5;i++){
                if(uRolls[i]==7){
                    uRolls[i]=-1;
                }
            }
            uActionCount=0;
            for(int i=0;i<5;i++){
                if(uRolls[i]==8){
                    uActionCount+=1;
                    uRolls[i]=5;
                }
                if(uRolls[i]==4 || uRolls[i]==17){
                    uActionCount+=1;
                    uRolls[i]=8;
                }
                if(uRolls[i]==2 || uRolls[i]==15){
                    uActionCount+=1;
                    uRolls[i]=4;
                }
                if(uRolls[i]==3){
                    uActionCount+=1;
                    uRolls[i]=6;
                }
                if(uRolls[i]==9){
                    uActionCount+=1;
                    uRolls[i]=7;
                }
                if(uRolls[i]==13){
                    uRolls[i]=9;
                    uActionCount+=1;
                }
                if(uRolls[i]==20 || uRolls[i]==23){
                    uRolls[i]=10;
                    uActionCount+=1;
                }
            }
            if(uActionCount==0){
                if(uGatlingCount>=3 && uDynamiteCount>=3){
                    dice.gatling(0);
                    EndTurn.setVisible(true);
                    rerollDice.setVisible(false);
                    finalizeDice.setVisible(false);
                    EndTurn.setDisable(false);
                }
                else if(uGatlingCount>=3){
                    dice.gatling(0);
                    EndTurn.setVisible(true);
                    rerollDice.setVisible(false);
                    finalizeDice.setVisible(false);
                    EndTurn.setDisable(false);
                }
                else if(uDynamiteCount>=3){
                    EndTurn.setVisible(true);
                    rerollDice.setVisible(false);
                    finalizeDice.setVisible(false);
                    EndTurn.setDisable(false);
                }
                else{
                    rerollDice.setVisible(false);
                    finalizeDice.setVisible(false);
                    EndTurn.setDisable(false); 
                }
            }
            Arrays.sort(uRolls);
            user.Action(expansions);
        }
    }
    @FXML public void switchAction(){
        pcArrow=0;
        caPile.setVisible(false);
        pcArrows[0].setVisible(true);
        ArrowPile+=1;
        aPile.setText("Arrows: "+ArrowPile);
        player_info[3][0]-=1;
        pArrows[0].setText("Arrows: "+player_info[3][0]);
        pcArrows[0].setImage(new Image("File:Pictures/Chief_Arrow.png"));
        for(int i=0;i<5;i++){
            dSwitch[i].setVisible(false);
        }
    }
    @FXML public void EndTurnAction(){
        if(expansions==false){
                rCount=0;
                oCount=0;
                for(int i=0;i<8;i++){
                    if(player_info[1][i]==1){
                        rCount+=1;
                    }
                    else if(player_info[1][i]==2){
                        oCount+=1;
                    }
                }
                if(player_info[2][pSheriff]<=0 && rCount==1 && pAlive==1){
                    Infobox.setText("Renegades Win");
                    pmanip.declare_roles();
                }
                else if(player_info[2][pSheriff]<=0){
                    Infobox.setText("Outlaws Win");
                    pmanip.declare_roles();
                }
                else if(player_info[2][pSheriff]>0 && rCount<=0 && oCount<=0){
                    Infobox.setText("Sheriff+Deputies Win");
                    pmanip.declare_roles();
                }
                else{
                    Infobox.setText("");
                    pTurnL.setText("User's Turn");
                    if(pTurn==0){
                        user.initial_turn();
                    }
                    else{
                        ai.AI_Turn(pTurn);
                    }   
                }
        }
        else{
            int pHuman=0;
            pZombies=0;
            oCount=0;
            rCount=1;
            Infobox.setText("");
            for(int i=0;i<PlayerCount;i++){
                if(player_info[1][i]==1){
                    rCount+=1;
                }
                if(player_info[1][i]==2){
                    oCount+=1;
                }
            }
            for(int i=0;i<PlayerCount;i++){
                if(player_info[2][i]>0 && player_info[1][i]==0){
                    pZombies+=1;
                }
                else if(player_info[2][i]>0 && player_info[1][i]!=0 && i!=pZombieMaster){
                    pHuman+=1;
                }
            }
            if(player_info[2][pSheriff]<=0 && rCount==1 && pAlive==1 && !Outbreak){
                    Infobox.setText("Renegades Win");
                    pmanip.declare_roles();
            }
            else if(player_info[2][pSheriff]<=0 && !Outbreak){
                Infobox.setText("Outlaws Win");
                pmanip.declare_roles();
            }
            else if(player_info[2][pSheriff]>0 && rCount<=0 && oCount<=0 && !Outbreak){
                Infobox.setText("Sheriff+Deputies Win");
                pmanip.declare_roles();
            }
            else if(pZombies==0 && Outbreak && player_info[2][pZombieMaster]<=0){
                Infobox.setText("Humans Win");
            }
            else if(pHuman==0 && Outbreak){
                Infobox.setText("Zombies Win");
            }
            else if(!Outbreak){
                Infobox.setText("");
                pTurn=(pTurn+1)%PlayerCount;
                pTurnL.setText("Player "+pTurn+"'s Turn");
                if(pTurn==0){
                    EndTurn.setVisible(false);
                    user.initial_turn(expansions);
                }
                else{
                    if(player_info[2][pTurn]<=0 && !Outbreak){
                        Random rand=new Random();
                        int temp=rand.nextInt(11);
                        while(BoneyardCards[temp]==-1){
                            temp=rand.nextInt(11);
                        }
                        if(BoneyardCards[temp]!=0){
                            ZombieHands+=BoneyardCards[temp];
                            BoneyardCards[temp]=-1;
                            ZombieHandsL.setText("Zombie Hands: "+ZombieHands);
                            Infobox.setText(Infobox.getText()+"Zombie hands increased to "+ZombieHands);
                            if(ZombieHands>pAlive){
                                Outbreak=true;
                                pmanip.summonZombies();
                                pTurn=((pTurn-1)+PlayerCount)%PlayerCount;
                                ZombieHandsL.setVisible(false);
                            }
                        }
                        else{
                            Infobox.setText(Infobox.getText()+"Player "+pTurn+" drew 0 hands");
                        }
                    }
                    else{
                        ai.AI_Turn(pTurn,expansions);
                    }
                }
            }
            else if(Outbreak){
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
                if(pTurn==0){
                    if(player_info[1][0]==0 || pZombieMaster==0){
                        user.initial_turn_zombie();
                    }
                    else{
                        user.initial_turn(expansions);
                    }
                }
                pTurnL.setText("Player "+pTurn+"'s Turn");
                if(player_info[1][pTurn]==0 || pTurn==pZombieMaster){
                    ai.AI_Zombie(pTurn);
                }
                else{
                    ai.AI_Turn(pTurn,expansions);
                }
            }
        }
    }
    @FXML public void p0ButtonAction(){
        if(uAction==1){
            dice.shot(0);
        }
        else if(uAction==2){
            if(player_info[2][0]<=4 && player_info[0][0]==3){
                dice.beer(0);
                Infobox.setText("User uses special ability as Jesse Jones to heal for 2 with Beer\n");
            }
            dice.beer(0);
        }
        else if(uAction==3){
            dice.duel(0);
        }
        if(uGatlingCount>=3){
            dice.gatling(0);
        }
        for(int i=0;i<8;i++){
            pButtons[i].setDisable(true);
            pButtons[i].setVisible(false);
        }
        if(uActionCount>0){
            if(!expansions){
                user.Action();
            }
            else{
                user.Action(expansions);
            }
        }
        else{
            finalizeDice.setVisible(false);
            rerollDice.setVisible(false);
            EndTurn.setVisible(true);
            EndTurn.setDisable(false);
            rerollsLeft.setVisible(false);
            if(uGatlingCount>=3){
                dice.gatling(0);
            }
            if(!expansions){
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dButtons[i].setOpacity(0);
            }
        }
        for(int i=0;i<5;i++){
            dSwitch[i].setVisible(false);
        }
    }
    @FXML public void p1ButtonAction(){
        if(uAction==1){
            dice.shot(1);
        }
        else if(uAction==2){
            dice.beer(1);
        }
        else if(uAction==3){
            dice.duel(1);
        }
        if(uGatlingCount>=3){
            dice.gatling(0);
        }
        for(int i=0;i<8;i++){
            pButtons[i].setDisable(true);
            pButtons[i].setVisible(false);
        }
        if(uActionCount>0){
            if(!expansions){
                user.Action();
            }
            else{
                user.Action(expansions);
            }
        }
        else{
            finalizeDice.setVisible(false);
            rerollDice.setVisible(false);
            EndTurn.setVisible(true);
            EndTurn.setDisable(false);
            rerollsLeft.setVisible(false);
            if(uGatlingCount>=3){
                dice.gatling(0);
            }
            if(!expansions){
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dButtons[i].setStyle("-fx-background-color: GREY");
            }
            
        }
    }
    @FXML public void p2ButtonAction(){
        if(uAction==1){
            dice.shot(2);
        }
        else if(uAction==2){
            dice.beer(2);
        }
        else if(uAction==3){
            dice.duel(2);
        }
        if(uGatlingCount>=3){
            dice.gatling(0);
        }
        for(int i=0;i<8;i++){
            pButtons[i].setDisable(true);
            pButtons[i].setVisible(false);
        }
        if(uActionCount>0){
            if(!expansions){
                user.Action();
            }
            else{
                user.Action(expansions);
            }
        }
        else{
            finalizeDice.setVisible(false);
            rerollDice.setVisible(false);
            EndTurn.setVisible(true);
            EndTurn.setDisable(false);
            rerollsLeft.setVisible(false);
            if(uGatlingCount>=3){
                dice.gatling(0);
            }
            if(!expansions){
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dButtons[i].setStyle("-fx-background-color: GREY");
            }
        }
    }
    @FXML public void p3ButtonAction(){
        if(uAction==1){
            dice.shot(3);
        }
        else if(uAction==2){
            dice.beer(3);
        }
        else if(uAction==3){
            dice.duel(3);
        }
        if(uGatlingCount>=3){
            dice.gatling(0);
        }
        for(int i=0;i<8;i++){
            pButtons[i].setDisable(true);
            pButtons[i].setVisible(false);
        }
        if(uActionCount>0){
            if(!expansions){
                user.Action();
            }
            else{
                user.Action(expansions);
            }
        }
        else{
            finalizeDice.setVisible(false);
            rerollDice.setVisible(false);
            EndTurn.setVisible(true);
            EndTurn.setDisable(false);
            rerollsLeft.setVisible(false);
            if(uGatlingCount>=3){
                dice.gatling(0);
            }
            if(!expansions){
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dButtons[i].setStyle("-fx-background-color: GREY");
            }
        }
    }
    @FXML public void p4ButtonAction(){
        if(uAction==1){
            dice.shot(4);
        }
        else if(uAction==2){
            dice.beer(4);
        }
        else if(uAction==3){
            dice.duel(4);
        }
        if(uGatlingCount>=3){
            dice.gatling(0);
        }
        for(int i=0;i<8;i++){
            pButtons[i].setDisable(true);
            pButtons[i].setVisible(false);
        }
        if(uActionCount>0){
            if(!expansions){
                user.Action();
            }
            else{
                user.Action(expansions);
            }
        }
        else{
            finalizeDice.setVisible(false);
            rerollDice.setVisible(false);
            EndTurn.setVisible(true);
            EndTurn.setDisable(false);
            rerollsLeft.setVisible(false);
            if(uGatlingCount>=3){
                dice.gatling(0);
            }
            if(!expansions){
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dButtons[i].setStyle("-fx-background-color: GREY");
            }
        }
    }
    @FXML public void p5ButtonAction(){
        if(uAction==1){
            dice.shot(5);
        }
        else if(uAction==2){
            dice.beer(5);
        }
        else if(uAction==3){
            dice.duel(5);
        }
        if(uGatlingCount>=3){
            dice.gatling(0);
        }
        for(int i=0;i<8;i++){
            pButtons[i].setDisable(true);
            pButtons[i].setVisible(false);
        }
        if(uActionCount>0){
            if(!expansions){
                user.Action();
            }
            else{
                user.Action(expansions);
            }
        }
        else{
            finalizeDice.setVisible(false);
            rerollDice.setVisible(false);
            EndTurn.setVisible(true);
            EndTurn.setDisable(false);
            rerollsLeft.setVisible(false);
            if(uGatlingCount>=3){
                dice.gatling(0);
            }
            if(!expansions){
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dButtons[i].setStyle("-fx-background-color: GREY");
            }
        }
    }
    @FXML public void p6ButtonAction(){
        if(uAction==1){
            dice.shot(6);
        }
        else if(uAction==2){
            dice.beer(6);
        }
        else if(uAction==3){
            dice.duel(6);
        }
        for(int i=0;i<8;i++){
            pButtons[i].setDisable(true);
            pButtons[i].setVisible(false);
        }
        if(uActionCount>0){
            if(!expansions){
                user.Action();
            }
            else{
                user.Action(expansions);
            }
        }
        else{
            finalizeDice.setVisible(false);
            rerollDice.setVisible(false);
            EndTurn.setVisible(true);
            EndTurn.setDisable(false);
            rerollsLeft.setVisible(false);
            if(uGatlingCount>=3){
                dice.gatling(0);
            }
            if(!expansions){
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dButtons[i].setStyle("-fx-background-color: GREY");
            }
        }
    }
    @FXML public void p7ButtonAction(){
        if(uAction==1){
            dice.shot(7);
        }
        else if(uAction==2){
            dice.beer(7);
        }
        else if(uAction==3){
            dice.duel(7);
        }
        if(uGatlingCount>=3){
            dice.gatling(0);
        }
        for(int i=0;i<8;i++){
            pButtons[i].setDisable(true);
            pButtons[i].setVisible(false);
        }
        if(uActionCount>0){
            if(!expansions){
                user.Action();
            }
            else{
                user.Action(expansions);
            }
        }
        else{
            finalizeDice.setVisible(false);
            rerollDice.setVisible(false);
            EndTurn.setVisible(true);
            EndTurn.setDisable(false);
            rerollsLeft.setVisible(false);
            if(uGatlingCount>=3){
                dice.gatling(0);
            }
            if(!expansions){
                pTurn=(pTurn+1)%PlayerCount;
                while(player_info[2][pTurn]<=0){
                    pTurn=(pTurn+1)%PlayerCount;
                }
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dButtons[i].setStyle("-fx-background-color: GREY");
            }
        }
    }
    @FXML public void d0Action(){
        if(d0Button.isSelected()){
            d0Button.setOpacity(0.333);
            d0Button.setStyle("-fx-background-color: GREEN");
        }
        else{
            d0Button.setOpacity(0);
            d0Button.setStyle("");
        }
    }
    @FXML public void d1Action(){
        if(d1Button.isSelected()){
            d1Button.setOpacity(0.333);
            d1Button.setStyle("-fx-background-color: GREEN");
        }
        else{
            d1Button.setOpacity(0);
            d1Button.setStyle("");
        }
    }
    @FXML public void d2Action(){
        if(d2Button.isSelected()){
            d2Button.setOpacity(0.333);
            d2Button.setStyle("-fx-background-color: GREEN");
        }
        else{
            d2Button.setOpacity(0);
            d2Button.setStyle("");
        }
    }
    @FXML public void d3Action(){
        if(d3Button.isSelected()){
            d3Button.setOpacity(0.333);
            d3Button.setStyle("-fx-background-color: GREEN");
        }
        else{
            d3Button.setOpacity(0);
            d3Button.setStyle("");
        }
    }
    @FXML public void d4Action(){
        if(d4Button.isSelected()){
            d4Button.setOpacity(0.333);
            d4Button.setStyle("-fx-background-color: GREEN");
        }
        else{
            d4Button.setOpacity(0);
            d4Button.setStyle("");
        }
    }
    @FXML public void pCowardAction(){
        pCoward.setVisible(false);
        pLoudmouth.setVisible(false);
        pNeither.setVisible(false);
        uType=1;
        user.user_next(1);
    }
    @FXML public void pLoudmouthAction(){
        pCoward.setVisible(false);
        pLoudmouth.setVisible(false);
        pNeither.setVisible(false);
        uType=2;
        user.user_next(2);
    }
    @FXML public void pNeitherAction(){
        pCoward.setVisible(false);
        pLoudmouth.setVisible(false);
        pNeither.setVisible(false);
        uType=0;
        user.user_next(0);
    }
    class GUIControl{
        public void StartDisappear(){
            StartingGameInstructions.setVisible(false);
            StartPlayers.setVisible(false);
            StartExpansions.setVisible(false);
            UserPlayers.setVisible(false);
            UserExpansions.setVisible(false);
            StartGameButton.setVisible(false);
        }
        public void GameDisappear(){
            for(int i=0;i<8;i++){
                pHP[i].setVisible(false);
                pTags[i].setVisible(false);
                pRoles[i].setVisible(false);
                pArrows[i].setVisible(false);
                pPics[i].setVisible(false);
                pButtons[i].setVisible(false);
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dPics[i].setVisible(false);
            }
            aPile.setVisible(false);
            rerollDice.setVisible(false);
            finalizeDice.setVisible(false);
            EndTurn.setVisible(false);
            rerollsLeft.setVisible(false);
            pCoward.setVisible(false);
            pLoudmouth.setVisible(false);
            pNeither.setVisible(false);
            ZombieHandsL.setVisible(false);
        }
        public void GameAppear(){
            for(int i=0;i<8;i++){
                pHP[i].setVisible(true);
                pTags[i].setVisible(true);
                pRoles[i].setVisible(true);
                pArrows[i].setVisible(true);
                pPics[i].setVisible(true);
            }
            for(int i=0;i<5;i++){
                dButtons[i].setVisible(false);
                dPics[i].setVisible(true);
            }
            aPile.setVisible(true);
            EndTurn.setVisible(true);
        }
        public void diceEnable(){
            for(int i=0;i<5;i++){
                dButtons[i].setDisable(false);
                dButtons[i].setVisible(true);
            }
            rerollDice.setDisable(false);
            rerollDice.setVisible(true);
            finalizeDice.setDisable(false);
            finalizeDice.setVisible(true);
            uRerolls=2;
            rerollsLeft.setText("Rerolls Left: "+uRerolls);
            rerollsLeft.setVisible(true);
        }
    }
    class Initialization{
        public void game(){
            setCharacters();
            setPics();
            setHP();
            setArrows();
            setRoles();
            setLabels();
            declareStuff();
            pAlive=PlayerCount;
            pTurn=pSheriff;
        }
        public void game(boolean expansions){
            setCharacters(expansions);
            setPics();
            setHP();
            setArrows(expansions);
            setRoles();
            setLabels();
            declareStuff();
            pAlive=PlayerCount;
            pTurn=((pSheriff-1)+PlayerCount)%PlayerCount;
            ZombieHandsL.setVisible(true);
            ZombieHands=0;
            Outbreak=false;
        }
        private void setCharacters(){
            int[]char_list={1,2,3,4,5,6,7,8};
            Random random=new Random();
            int rand_int;
            int temp;
               for(int i=0;i<char_list.length;i++){
                rand_int=random.nextInt(8);
                temp=char_list[i];
                char_list[i]=char_list[rand_int];
                char_list[rand_int]=temp;
            }
            for(int i=0;i<PlayerCount;i++){
                player_info[0][i]=char_list[i];
            }
            for(int i=PlayerCount;i<8;i++){
                player_info[0][i]=0;
            }
        }
        private void setCharacters(boolean expansions){
            int[]char_list={1,2,3,4,5,6,7,8,9,10,11,12};
            Random random=new Random();
            int rand_int;
            int temp;
               for(int i=0;i<char_list.length;i++){
                rand_int=random.nextInt(12);
                temp=char_list[i];
                char_list[i]=char_list[rand_int];
                char_list[rand_int]=temp;
            }
            for(int i=0;i<PlayerCount;i++){
                player_info[0][i]=char_list[i];
            }
            for(int i=PlayerCount;i<8;i++){
                player_info[0][i]=0;
            }
        }
        private void setPics(){
            for(int i=0;i<8;i++){
                if(player_info[0][i]==0){
                    pPics[i].setImage(new Image("File:Pictures/no_char.png"));
                }
                else if(player_info[0][i]==1){
                    pPics[i].setImage(new Image("File:Pictures/Black_Jack.png"));
                }
                else if(player_info[0][i]==2){
                    pPics[i].setImage(new Image("File:Pictures/Calamity_Janet.png"));
                }
                else if(player_info[0][i]==3){
                    pPics[i].setImage(new Image("File:Pictures/Jesse_Jones.png"));
                }
                else if(player_info[0][i]==4){
                    pPics[i].setImage(new Image("File:Pictures/Jourdonnais.png"));
                }
                else if(player_info[0][i]==5){
                    pPics[i].setImage(new Image("File:Pictures/Suzy_Lafayette.png"));
                }
                else if(player_info[0][i]==6){
                    pPics[i].setImage(new Image("File:Pictures/Paul_Regret.png"));
                }
                else if(player_info[0][i]==7){
                    pPics[i].setImage(new Image("File:Pictures/Rose_Doolan.png"));
                }
                else if(player_info[0][i]==8){
                    pPics[i].setImage(new Image("File:Pictures/Vulture_Sam.png"));
                }
                else if(player_info[0][i]==9){
                    pPics[i].setImage(new Image("File:Pictures/Apache_Kid.png"));
                }
                else if(player_info[0][i]==10){
                    pPics[i].setImage(new Image("File:Pictures/Bill_Noface.png"));
                }
                else if(player_info[0][i]==11){
                    pPics[i].setImage(new Image("File:Pictures/Belle_Star.png"));
                }
                else if(player_info[0][i]==12){
                    pPics[i].setImage(new Image("File:Pictures/Greg_Digger.png"));
                }
            }
        }
        private void setHP(){
            for(int i=0;i<8;i++){
                if(player_info[0][i]==1 || player_info[0][i]==2 || player_info[0][i]==5 || player_info[0][i]==11){
                    pHP[i].setText("HP: 8");
                    player_info[2][i]=8;
                    player_info[4][i]=8;
                }
                else if(player_info[0][i]==3 || player_info[0][i]==6 || player_info[0][i]==7 || player_info[0][i]==8 || player_info[0][i]==9 || player_info[0][i]==10){
                    pHP[i].setText("HP: 9");
                    player_info[2][i]=9;
                    player_info[4][i]=9;
                }
                else if(player_info[0][i]==4 || player_info[0][i]==12){
                    pHP[i].setText("HP: 7");
                    player_info[2][i]=7;
                    player_info[4][i]=7;
                }
                else if(player_info[0][i]==0){
                    pHP[i].setText("N/A");
                    player_info[2][i]=0;
                    player_info[4][i]=0;
                }
            }
        }
        private void setArrows(){
            ArrowPile=9;
            aPile.setText("Arrows in Pile: 9");
            for(int i=0;i<PlayerCount;i++){
                pArrows[i].setText("Arrows: 0");
                player_info[3][i]=0;
            }
            for(int i=PlayerCount;i<8;i++){
                pArrows[i].setText("N/A");
                player_info[3][i]=0;
            }
        }
        private void setArrows(boolean expansions){
            ArrowPile=9;
            pcArrow=-1;
            caPile.setVisible(true);
            caPile.setImage(new Image("File:Pictures/Chief_Arrow.png"));
            aPile.setText("Arrows in Pile: 9");
            for(int i=0;i<PlayerCount;i++){
                pArrows[i].setText("Arrows: 0");
                player_info[3][i]=0;
            }
            for(int i=PlayerCount;i<8;i++){
                pArrows[i].setText("N/A");
                player_info[3][i]=0;
            }
        }
        private void setRoles(){
            Random rand=new Random();
            int rand_int;
            int temp;
            if(PlayerCount==4){
                int[]roles={1,4,2,2};
                rCount=1;
                oCount=2;
                for(int i=0;i<roles.length;i++){
                  rand_int=rand.nextInt(4);
                  temp=roles[i];
                  roles[i]=roles[rand_int];
                  roles[rand_int]=temp;
                }
                for(int i=0;i<PlayerCount;i++){
                    player_info[1][i]=roles[i];
                }
                for(int i=PlayerCount;i<8;i++){
                    player_info[1][i]=0;
                }
            }  
            else if(PlayerCount==5){
                int[]roles={1,4,2,2,3};
                oCount=2;
                rCount=1;
                for(int i=0;i<roles.length;i++){
                  rand_int=rand.nextInt(5);
                  temp=roles[i];
                  roles[i]=roles[rand_int];
                  roles[rand_int]=temp;
                }
                for(int i=0;i<PlayerCount;i++){
                    player_info[1][i]=roles[i];
                }
                for(int i=PlayerCount;i<8;i++){
                    player_info[1][i]=0;
                }
            }  
            else if(PlayerCount==6){
                int[]roles={1,4,2,2,3,2};
                rCount=1;
                oCount=3;
                for(int i=0;i<roles.length;i++){
                  rand_int=rand.nextInt(6);
                  temp=roles[i];
                  roles[i]=roles[rand_int];
                  roles[rand_int]=temp;
                }
                for(int i=0;i<PlayerCount;i++){
                    player_info[1][i]=roles[i];
                }
                for(int i=PlayerCount;i<8;i++){
                    player_info[1][i]=0;
                }
            }  
            else if(PlayerCount==7){
                int[]roles={1,4,2,2,3,2,3};
                rCount=1;
                oCount=3;
                for(int i=0;i<roles.length;i++){
                  rand_int=rand.nextInt(7);
                  temp=roles[i];
                  roles[i]=roles[rand_int];
                  roles[rand_int]=temp;
                }
                for(int i=0;i<PlayerCount;i++){
                    player_info[1][i]=roles[i];
                }
                for(int i=PlayerCount;i<8;i++){
                    player_info[1][i]=0;
                }
            } 
            else if(PlayerCount==8){
                int[]roles={1,4,2,2,3,2,3,1};
                rCount=2;
                oCount=3;
                for(int i=0;i<roles.length;i++){
                  rand_int=rand.nextInt(8);
                  temp=roles[i];
                  roles[i]=roles[rand_int];
                  roles[rand_int]=temp;
                }
                for(int i=0;i<PlayerCount;i++){
                    player_info[1][i]=roles[i];
                }
                for(int i=PlayerCount;i<8;i++){
                    player_info[1][i]=0;
                }
            }
            for(int i=0;i<8;i++){
                if(player_info[1][i]==4){
                    pRoles[i].setText("Role: Sheriff");
                    pSheriff=i;
                    player_info[2][i]+=2;
                    player_info[4][i]+=2;
                    pHP[i].setText("HP: "+player_info[2][i]);
                }
                else if(player_info[1][i]!=0){
                    pRoles[i].setText("Role: Unknown");
                }
                else{
                    pRoles[i].setText("N/A");
                }
            }
        }
        private void setLabels(){
            p0Tag.setText("Player 0(User)");
            for(int i=1;i<PlayerCount;i++){
                pTags[i].setText("Player "+i);
            }
            for(int i=PlayerCount;i<8;i++){
                pTags[i].setText("N/A");
            }
        }
        private void declareStuff(){
            Infobox.setText("");
            for(int i=0;i<8;i++){
                if(player_info[0][i]==1){
                    String info=Infobox.getText();
                    info+="- Player "+i+" is Black Jack(8 HP) \nAbility: May re-roll Dynamite\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==2){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Calamity Janet(8 HP)\nAbility: Can use 1shot as 2shot and vice-versa\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==3){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Jesse Jones(9 HP)\nAbility: If you have 4 HP or less beer heals yourself for 2\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==4){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Jourdonnais(7 HP)\nAbility: Never lose more than 1 HP to indians\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==5){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Lucky Duke(8 HP)\nAbility: May make one more re-roll\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==6){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Paul Regret(9 HP)\nAbility: Never lose HP to Gatling Gun\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==7){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Rose Doolan(9 HP)\nAbility: May use 1shot and 2shot on players sitting one spot further\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==8){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Vulture Sam(9 HP)\nAbility: Gains 2 HP after another player gets eliminated\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==9){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Apache Kid(9 HP)\nAbility: If you roll Arrow, may take Chief's Arrow from another player\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==10){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Bill Noface(9 HP)\nAbility: Apply Arrow results after your last roll\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==11){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Belle Star(8 HP)\nAbility: After each dice rolls, you can change 1 dynamite to gatling\n";
                    Infobox.setText(info);
                }
                else if(player_info[0][i]==12){
                    String info=Infobox.getText();
                    info+="- Player "+ i + " is Greg Digger(7 HP)\nAbility: May use whiskey twice\n";
                    Infobox.setText(info);
                }
            }
            for(int i=0;i<8;i++){
                if(player_info[1][i]==4){
                    Infobox.setText(Infobox.getText()+"Player "+i+" is Sheriff(Starts game along with gets 2 more HP)\n");
                }
            }
            if(player_info[1][0]==1){
                pRoles[0].setText("Role: Renegade");
                Infobox.setText(Infobox.getText()+"User is Renegade\n");
            }
            else if(player_info[1][0]==2){
                pRoles[0].setText("Role: Outlaw");
                Infobox.setText(Infobox.getText()+"User is Outlaw\n");
            }
            else if(player_info[1][0]==3){
                pRoles[0].setText("Role: Deputy");
                Infobox.setText(Infobox.getText()+"User is Deputy\n");
            }
            else if(player_info[1][0]==4){
                pRoles[0].setText("Role: Sheriff");
                Infobox.setText(Infobox.getText()+"User is Sheriff\n");
            }
            Infobox.setText(Infobox.getText()+"Press End Turn to go to Sheriff's turn\n");
        }
    }
    class dice_actions{
        public int[]roll(){
            Random rand=new Random();
            int[]rolls=new int[5];
            for(int i=0;i<5;i++){
                rolls[i]=rand.nextInt(6);
                if(rolls[i]==0){
                    dPics[i].setImage(new Image("File:Pictures/Arrow_Dice.png"));
                }
                else if(rolls[i]==1){
                    dPics[i].setImage(new Image("File:Pictures/Dynamite_Dice.png"));
                }
                else if(rolls[i]==2){
                    dPics[i].setImage(new Image("File:Pictures/1shot_Dice.png"));
                }
                else if(rolls[i]==3){
                    dPics[i].setImage(new Image("File:Pictures/2shot_Dice.png"));
                }
                else if(rolls[i]==4){
                    dPics[i].setImage(new Image("File:Pictures/Beer_Dice.png"));
                }
                else if(rolls[i]==5){
                    dPics[i].setImage(new Image("File:Pictures/Gatling_Dice.png"));
                }
            }
            return rolls;
        }
        public int[]roll(boolean expansions,int dice){
            Random rand=new Random();
            int[]rolls=new int[5];
            if(dice==-1){
                for(int i=0;i<3;i++){
                    rolls[i]=rand.nextInt(6);
                }
                rolls[3]=-1;
                rolls[4]=-1;
            }
            if(dice==0){
                rolls[0]=rand.nextInt(6);
                rolls[1]=rand.nextInt(6);
                rolls[2]=rand.nextInt(6);
                rolls[3]=rand.nextInt(6)+18;
                rolls[4]=rand.nextInt(6)+18;
            }
            if(dice==1){
                rolls[0]=rand.nextInt(6)+12;
                rolls[1]=rand.nextInt(6);
                rolls[2]=rand.nextInt(6);
                rolls[3]=rand.nextInt(6)+18;
                rolls[4]=rand.nextInt(6)+18;
            }
            if(dice==2){
                rolls[0]=rand.nextInt(6)+6;
                rolls[1]=rand.nextInt(6);
                rolls[2]=rand.nextInt(6);
                rolls[3]=rand.nextInt(6)+18;
                rolls[4]=rand.nextInt(6)+18;
            }
            return rolls;
        }
        public void show_dice(int[]rolls){
            for(int i=0;i<5;i++){
                if(rolls[i]==-1){
                    dPics[i].setImage(new Image("File:Pictures/no_char.png"));
                }
                else if(rolls[i]==-2){
                    dPics[i].setImage(new Image("File:Pictures/Arrow_Dice.png"));
                }
                if(rolls[i]==0 || rolls[i]==10 || rolls[i]==16 || rolls[i]==22){
                    dPics[i].setImage(new Image("File:Pictures/Arrow_Dice.png"));
                }
                else if(rolls[i]==1 || rolls[i]==6 || rolls[i]==12 || rolls[i]==18){
                    dPics[i].setImage(new Image("File:Pictures/Dynamite_Dice.png"));
                }
                else if(rolls[i]==2 || rolls[i]==15){
                    dPics[i].setImage(new Image("File:Pictures/1shot_Dice.png"));
                }
                else if(rolls[i]==3){
                    dPics[i].setImage(new Image("File:Pictures/2shot_Dice.png"));
                }
                else if(rolls[i]==4 || rolls[i]==17){
                    dPics[i].setImage(new Image("File:Pictures/Beer_Dice.png"));
                }
                else if(rolls[i]==5 || rolls[i]==21){
                    dPics[i].setImage(new Image("File:Pictures/Gatling_Dice.png"));
                }
                else if(rolls[i]==7){
                    dPics[i].setImage(new Image("File:Pictures/Bullet_Dice.png"));
                }
                else if(rolls[i]==8){
                    dPics[i].setImage(new Image("File:Pictures/Double1shot_Dice.png"));
                }
                else if(rolls[i]==9){
                    dPics[i].setImage(new Image("File:Pictures/Double2shot_Dice.png"));
                }
                else if(rolls[i]==11){
                    dPics[i].setImage(new Image("File:Pictures/Doublegatling_Dice.png"));
                }
                else if(rolls[i]==13){
                    dPics[i].setImage(new Image("File:Pictures/Doublebeer_Dice.png"));
                }
                else if(rolls[i]==14){
                    dPics[i].setImage(new Image("File:Pictures/Brokenarrow_Dice.png"));
                }
                else if(rolls[i]==19){
                    dPics[i].setImage(new Image("File:Pictures/Whiskey_Dice.png"));
                }
                else if(rolls[i]==20 || rolls[i]==23){
                    dPics[i].setImage(new Image("File:Pictures/Duel_Dice.png"));
                }
            }
        }
        public void arrows(int player_turn){
            ArrowPile=ArrowPile-1;
            aPile.setText("Arrows Left in Pile: "+ArrowPile);
            player_info[3][player_turn]+=1;
            pArrows[player_turn].setText("Arrows: "+player_info[3][player_turn]);
            Infobox.setText(Infobox.getText()+"-Player " + player_turn + " Takes an arrow\n");
            if(ArrowPile==0){
                ArrowPile=9;
                aPile.setText("Arrows Left in Pile: "+ArrowPile);
                Infobox.setText(Infobox.getText()+"-All players take damage based on arrow count\n-Player arrows drop to 0\n-arrows in pile go back to 9\n");
                for(int i=0;i<PlayerCount;i++){
                    if(player_info[0][i]==4){
                        if(player_info[3][i]>=1){
                            player_info[2][i]=player_info[2][i]-1;
                            pArrows[i].setText("Arrows: 0");
                            pHP[i].setText("HP: "+player_info[2][i]);
                            player_info[3][i]=0;
                            if(player_info[2][i]<=0){
                                pmanip.check_dead(i);
                            }
                        }
                    }
                    else{
                        player_info[2][i]=player_info[2][i]-player_info[3][i];
                        pArrows[i].setText("Arrows: 0");
                        pHP[i].setText("HP: "+player_info[2][i]);
                        player_info[3][i]=0;
                        if(player_info[2][i]<=0){
                                pmanip.check_dead(i);
                            }
                    }
                }
            }   
        }
        public void arrows(int player_turn, boolean expansions){
            player_info[3][player_turn]+=1;
            ArrowPile-=1;
            pArrows[player_turn].setText("Arrows: "+player_info[3][player_turn]);
            aPile.setText("Arrows in Pile: "+ArrowPile);
            Infobox.setText(Infobox.getText()+"Player "+player_turn+" receives an arrow\n");
            if(ArrowPile==0){
                Infobox.setText(Infobox.getText()+"Player "+player_turn+" receives an arrow\nArrow Pile is 0, all players lose HP equal to arrow count\nexcept for if person with chief arrow has most arrows\n");
                int take_damage=0;
                for(int i=0;i<PlayerCount;i++){
                    if(player_info[3][pcArrow]+2<=player_info[3][i] && i!=pcArrow){
                        take_damage=1;
                    }
                }
                if(take_damage==1){
                    player_info[2][pcArrow]=player_info[2][pcArrow]-(player_info[3][pcArrow]+2);
                    player_info[3][pcArrow]=0;
                    pArrows[pcArrow].setText("Arrows: 0");
                    pmanip.check_dead(pcArrow);
                    caPile.setVisible(true);
                    pcArrows[pcArrow].setVisible(false);
                    pcArrow=-1;
                }
                else{
                    player_info[3][pcArrow]=0;
                    pArrows[pcArrow].setText("Arrows: 0");
                    caPile.setVisible(true);
                    pcArrows[pcArrow].setVisible(false);
                    pcArrow=-1;
                }
                for(int i=0;i<PlayerCount;i++){
                    if(i!=pcArrow && player_info[0][i]!=4){
                        player_info[2][i]=player_info[2][i]-player_info[3][i];
                        player_info[3][i]=0;
                        pArrows[i].setText("Arrows: 0");
                        pmanip.check_dead(i);
                    }
                    if(i!=pcArrow && player_info[0][i]==4){
                        if(player_info[3][i]>0){
                            player_info[2][i]-=1;
                            pArrows[i].setText("Arrows: 0");
                            player_info[3][i]=0;
                            pmanip.check_dead(i);
                        }
                    }
                }
                ArrowPile=9;
                aPile.setText("Arrows in Pile: 9");
                pcArrow=-1;
                caPile.setVisible(true);
                for(int i=0;i<PlayerCount;i++){
                    pcArrows[i].setVisible(false);
                }        
            }
        }
        public void dynamite(int player){
            player_info[2][player]-=1;
            pHP[player].setText("HP: "+player_info[2][player]);
            Infobox.setText(Infobox.getText()+"-Player "+ player + " takes 1 damage from dynamite\n");
        }
        public void beer(int player_target){
            if(player_info[2][player_target]<player_info[4][player_target]){
                player_info[2][player_target]+=1;
                pHP[player_target].setText("HP: "+player_info[2][player_target]);
                Infobox.setText(Infobox.getText()+"Player "+player_target+" gains 1 life point due to beer(or ability)\n");
            }
            else{
                Infobox.setText(Infobox.getText()+"Player uses beer on player with max HP\n");
            }
        }
        public void shot(int player_target){
            player_info[2][player_target]-=1;
            pHP[player_target].setText("HP: "+player_info[2][player_target]);
            Infobox.setText(Infobox.getText()+"-Player "+ player_target + " takes 1 damage from shot\n");
            pmanip.check_dead(player_target);
        }
        public void gatling(int player){
            Infobox.setText(Infobox.getText()+"Gatling hits all players minus player "+player+"\nall players hit by gatling lose 1 HP\nPlayer "+player+" discards all arrows\n");
            for(int i=0;i<PlayerCount;i++){
                if(player_info[2][i]>0 && i!=player && player_info[1][i]!=6){
                    player_info[2][i]-=1;
                    pHP[i].setText("HP: "+player_info[2][i]);
                    pmanip.check_dead(i);
                }
            }
            ArrowPile+=player_info[3][player];
            player_info[3][player]=0;
            pArrows[player].setText("Arrows: 0");
        }
        public int[]reroll(int[]rolls,boolean[]reroll){
            Random rand=new Random();
            for(int i=0;i<5;i++){
                if(reroll[i]==true){
                    rolls[i]=rand.nextInt(6);
                    if(rolls[i]==0){
                        dPics[i].setImage(new Image("File:Pictures/Arrow_Dice.png"));
                    }
                    else if(rolls[i]==1){
                        dPics[i].setImage(new Image("File:Pictures/Dynamite_Dice.png"));
                    }
                    else if(rolls[i]==2){
                        dPics[i].setImage(new Image("File:Pictures/1shot_Dice.png"));
                    }
                    else if(rolls[i]==3){
                        dPics[i].setImage(new Image("File:Pictures/2shot_Dice.png"));
                    }
                    else if(rolls[i]==4){
                        dPics[i].setImage(new Image("File:Pictures/Beer_Dice.png"));
                    }
                    else if(rolls[i]==5){
                        dPics[i].setImage(new Image("File:Pictures/Gatling_Dice.png"));
                    }
                }
            }
            return rolls;
        }
        public int[]reroll(int[]rolls,boolean[]reroll,boolean expansions){
            Random rand=new Random();
            if(reroll[0]==true){
                if(uType==0){
                    uRolls[0]=rand.nextInt(6);
                }
                if(uType==1){
                    uRolls[0]=rand.nextInt(6)+12;
                }
                if(uType==2){
                    uRolls[0]=rand.nextInt(6)+6;
                }
            }
            if(reroll[1]==true){
                uRolls[1]=rand.nextInt(6);
            }
            if(reroll[2]==true){
                uRolls[2]=rand.nextInt(6);
            }
            if(reroll[3]==true){
                uRolls[3]=rand.nextInt(6)+18;
            }
            if(reroll[4]==true){
                uRolls[4]=rand.nextInt(6)+18;
            }
            dice.show_dice(uRolls);
            return uRolls;
        }
        public void duel(int player){
            Random rand=new Random();
            if(rand.nextInt()==1 || rand.nextInt()==2){
                Infobox.setText(Infobox.getText()+"Player "+player+" rolled duel so no damage\n");
            }
            else{
                player_info[2][player]-=1;
                pHP[player].setText("HP: "+player_info[2][player]);
                pmanip.check_dead(player);
                Infobox.setText(Infobox.getText()+"Player "+player+" did not roll duel so takes 1 damage\n");
            }
        }
        public void brokenarrow(int player){
            if(player_info[3][player]>0){
                player_info[3][player]-=1;
                Infobox.setText(Infobox.getText()+"Broken arrow used on "+player+" to reduce their arrow count by 1\n");
                pArrows[player].setText("Arrows: "+player_info[3][player]);
            }
            else{
                Infobox.setText(Infobox.getText()+"Broken arrow wasted on player with max arrows\n");
            }
        }
        public void bullet(int player){
            player_info[2][player]-=1;
            pHP[player].setText("HP: "+player_info[2][player]);
            pmanip.check_dead(player);
            Infobox.setText(Infobox.getText()+"Player loses 1 HP to bullet\n");
        }
    }
    class player_manipulation{
            public void check_dead(int player){
            if(player_info[2][player]<=0){
                pAlive-=1;
                pHP[player].setText("Dead");
                ArrowPile+=player_info[3][player];
                player_info[3][player]=0;
                player_info[2][player]=0;
                pArrows[player].setText("N/A");
                pPics[player].setImage(new Image("File:Pictures/Char_Dead.png"));
                if(player_info[1][player]==1){
                    pRoles[player].setText("Role: Renegade");
                    rCount-=1;
                }
                else if(player_info[1][player]==2){
                    pRoles[player].setText("Role: Outlaw");
                    oCount-=1;
                }
                else if(player_info[1][player]==3){
                    pRoles[player].setText("Role: Deputy");
                }
                Infobox.setText(Infobox.getText()+"Player "+player+" is dead\n");
                for(int i=0;i<PlayerCount;i++){
                    if(player_info[0][i]==8 && player_info[2][i]>0){
                        dice.beer(i);
                        dice.beer(i);
                        Infobox.setText(Infobox.getText()+"Vulture Sam gains 2 life when player died\n");
                    }
                }
                if(pcArrow==player){
                    pcArrow=-1;
                    pcArrows[player].setVisible(false);
                    caPile.setVisible(true);
                }
            }
        }
            public void declare_roles(){
                for(int i=0;i<PlayerCount;i++){
                    if(player_info[1][i]==1){
                        pRoles[i].setText("Role: Renegade");
                    }
                    else if(player_info[1][i]==2){
                        pRoles[i].setText("Role: Outlaw");
                    }
                    else if(player_info[1][i]==3){
                        pRoles[i].setText("Role: Deputy");
                    }
                    else if(player_info[1][i]==4){
                        pRoles[i].setText("Role: Sheriff");
                    }
                }
            }
            public void summonZombies(){
                int zmCount=0;
                pAlive=0;
                for(int i=0;i<PlayerCount;i++){
                    if(player_info[2][i]>0){
                        pAlive+=1;
                    }
                }
                for(int i=0;i<PlayerCount;i++){
                    if(player_info[2][i]<=0){
                        player_info[2][i]=pAlive;
                        player_info[1][i]=0;
                        player_info[3][i]=0;
                        pPics[i].setImage(new Image("File:Pictures/Zombie.png"));
                        pHP[i].setText("HP: "+pAlive);
                        pRoles[i].setText("Role: Zombie");
                        pArrows[i].setText("Arrows: 0");
                    }
                    if(player_info[1][i]==1 && zmCount==0){
                        zmCount+=1;
                        pZombieMaster=i;
                        pPics[i].setImage(new Image("File:Pictures/zombiemaster.png"));
                        pRoles[i].setText("Role: Zombie Master");
                    }
                }
            }
    }
    class user_turn{
        public void initial_turn(){
            uRolls=dice.roll();
            uDynamiteCount=0;
            GUIControl.diceEnable();
            for(int i=0;i<5;i++){
                if(uRolls[i]==1 && player_info[0][0]!=1){
                    dButtons[i].setStyle("-fx-background-color: RED");
                    dButtons[i].setOpacity(0.333);
                    dButtons[i].setDisable(true);
                    uDynamiteCount+=1;
                }
                else if(uRolls[i]==0){
                    dice.arrows(0);
                    uRolls[i]=-1;
                }
            }
            if(uDynamiteCount>=3){
                finalizeDiceAction();
            }
            EndTurn.setVisible(false);
            EndTurn.setDisable(true);          
        }
        public void initial_turn(boolean expansions){
            pCoward.setVisible(true);
            pLoudmouth.setVisible(true);
            pNeither.setVisible(true);
            pCoward.setDisable(false);
            pLoudmouth.setDisable(false);
            pNeither.setDisable(false);
            for(int i=0;i<5;i++){
                dPics[i].setVisible(false);
                dButtons[i].setVisible(false);
            }
            Infobox.setText(Infobox.getText()+"Click Loudmouth for loudmouth die\n Click Coward for Coward die\nClick neither for normal die\n");
        }
        public void user_next(int type){
            if(type==0){
                uRolls=dice.roll(expansions,type);
            }
            if(type==1){
                uRolls=dice.roll(expansions,type);
            }
            if(type==2){
                uRolls=dice.roll(expansions,type);
            }
            for(int i=0;i<5;i++){
                dPics[i].setVisible(true);
                dButtons[i].setVisible(true);
                dButtons[i].setDisable(false);
            }
            dice.show_dice(uRolls);
            for(int i=0;i<5;i++){
                if((uRolls[i]==1 || uRolls[i]==6 || uRolls[i]==12 || uRolls[i]==18) && player_info[0][0]!=1){
                    dButtons[i].setStyle("-fx-background-color: RED");
                    dButtons[i].setOpacity(0.333);
                    dButtons[i].setDisable(true);
                    uDynamiteCount+=1;
                }
                if(uRolls[i]==7){
                    dice.bullet(0);
                }
                else if((uRolls[i]==0 || uRolls[i]==10 || uRolls[i]==16 || uRolls[i]==22) && player_info[1][0]!=10){
                    dice.arrows(0,expansions);
                    uRolls[i]=-2;
                    if(pcArrow==-1){
                        dSwitch[i].setVisible(true);
                        dSwitch[i].setDisable(false);
                        dSwitch[i].setText("Take Chief Arrow?");
                    }
                }
            }
            if(uDynamiteCount>=3){
                finalizeDiceAction();
            }
            EndTurn.setVisible(false);
            EndTurn.setDisable(true);  
            finalizeDice.setVisible(true);
            finalizeDice.setDisable(false);
            rerollDice.setVisible(true);
            rerollDice.setDisable(false);
            uRerolls=2;
            rerollsLeft.setVisible(true);
            rerollsLeft.setText("Rerolls Left: 2");
        }
        public void Action(){
            uActionCount-=1;
            for(int i=0;i<5;i++){
                if(uRolls[i]==2 || uRolls[i]==3){
                    uAction=1;
                }
                else{
                    uAction=0;
                }
                if(player_info[0][0]==2 && (uRolls[i]==2 || uRolls[i]==3)){
                    Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n As Calamity Janet you can use 1shots as 2shots and vice versa\n");
                    if(pAlive>4){
                        uAction=1;
                        int j=1;
                        int k=-1;
                        int l=2;
                        int m=-2;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                        while(player_info[2][l]<=0 && l!=j){
                            l+=1;
                        }
                        while(player_info[2][(m+PlayerCount)%PlayerCount]<=0 && m!=k){
                            m-=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        pButtons[l].setVisible(true);
                        pButtons[l].setDisable(false);
                        pButtons[(m+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(m+PlayerCount)%PlayerCount].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    if(pAlive==4){
                        int j=1;
                        int k=-1;
                        int l=2;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                        while(player_info[2][l]<=0 && l!=j){
                            l+=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        pButtons[l].setVisible(true);
                        pButtons[l].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    if(pAlive==3){
                        int j=1;
                        int k=-1;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    if(pAlive==2){
                        int j=1;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                }
                if(player_info[0][0]==7 && uRolls[i]==2){
                    Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n As Rose Doolan you can use 1shots and 2shots 1 spot further\n");
                    if(pAlive>4){
                        uAction=1;
                        int j=1;
                        int k=-1;
                        int l=2;
                        int m=-2;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                        while(player_info[2][l]<=0 && l!=j){
                            l+=1;
                        }
                        while(player_info[2][(m+PlayerCount)%PlayerCount]<=0 && m!=k){
                            m-=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        pButtons[l].setVisible(true);
                        pButtons[l].setDisable(false);
                        pButtons[(m+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(m+PlayerCount)%PlayerCount].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    if(pAlive==4){
                        int j=1;
                        int k=-1;
                        int l=2;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                        while(player_info[2][l]<=0 && l!=j){
                            l+=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        pButtons[l].setVisible(true);
                        pButtons[l].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    if(pAlive==3){
                        int j=1;
                        int k=-1;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    if(pAlive==2){
                        int j=1;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                }
                if(player_info[0][0]==7 && uRolls[i]==3){
                    Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n As Rose Doolan you can use 1shots and 2shots 1 spot further\n");
                    if(pAlive>4){
                        uAction=1;
                        int j=2;
                        int k=-2;
                        int l=3;
                        int m=-3;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                        while(player_info[2][l]<=0 && l!=j){
                            l+=1;
                        }
                        while(player_info[2][(m+PlayerCount)%PlayerCount]<=0 && m!=k){
                            m-=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        pButtons[l].setVisible(true);
                        pButtons[l].setDisable(false);
                        pButtons[(m+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(m+PlayerCount)%PlayerCount].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    if(pAlive==4){
                        int j=1;
                        int k=-1;
                        int l=2;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                        while(player_info[2][l]<=0 && l!=j){
                            l+=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        pButtons[l].setVisible(true);
                        pButtons[l].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    if(pAlive==3){
                        int j=1;
                        int k=-1;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    if(pAlive==2){
                        int j=1;
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                }
                if(uRolls[i]==2 && pAlive>2){
                    Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                    uAction=1;
                    int j=1;
                    int k=-1;
                    if(player_info[2][j]<=0){
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                    }
                    if(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                    }
                    pButtons[j].setVisible(true);
                    pButtons[j].setDisable(false);
                    pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                    pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                    uRolls[i]=-1;
                    break;
                }
                else if(uRolls[i]==2 && pAlive==2){
                    int alive=1;
                    Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                    while(player_info[2][alive]<=0){
                        alive+=1;
                    }
                    pButtons[alive].setVisible(true);
                    pButtons[alive].setDisable(false);
                    uRolls[i]=-1;
                    break;
                }
                else if(uRolls[i]==3 && pAlive>2){
                    Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                    uAction=1;
                    int j=2;
                    int k=-2;
                    if(player_info[2][j]<=0){
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                    }
                    if(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                    }
                    pButtons[j].setVisible(true);
                    pButtons[j].setDisable(false);
                    pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                    pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                    uRolls[i]=-1;
                    break;
                }
                else if(uRolls[i]==3 && pAlive==2){
                    int alive=1;
                    Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                    while(player_info[2][alive]<=0){
                        alive+=1;
                    }
                    pButtons[alive].setVisible(true);
                    pButtons[alive].setDisable(false);
                    uRolls[i]=-1;
                    break;
                }
                else if(uRolls[i]==4){
                    Infobox.setText(Infobox.getText()+"Click a player to heal(red players are eligible to be healed)\n");
                    uAction=2;
                    for(int j=0;j<PlayerCount;j++){
                        if(player_info[2][j]>0){
                            pButtons[j].setVisible(true);
                            pButtons[j].setDisable(false);
                        }
                    }
                    uRolls[i]=-1;
                    break;
                }
            }
        }
        public void Action(boolean expansions){
            for(int i=0;i<5;i++){
                if(uRolls[i]==4){
                    uActionCount-=1;
                    uAction=1;
                    if(uRolls[i]==4 && pAlive>2){
                        Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                        uAction=1;
                        int j=1;
                        int k=-1;
                        if(player_info[2][j]<=0){
                            while(player_info[2][j]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                    else if(uRolls[i]==4 && pAlive==2){
                        int alive=1;
                        Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        pButtons[alive].setVisible(true);
                        pButtons[alive].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                }
                if(uRolls[i]==5){
                    uAction=1;
                    if(uRolls[i]==5 && pAlive>2){
                        Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                        uAction=1;
                        int j=1;
                        int k=-1;
                        if(player_info[2][j]<=0){
                            while(player_info[2][j]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        pButtons[j].setVisible(true);
                        pButtons[j].setDisable(false);
                        pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                        pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                        uRolls[i]-=1;
                        break;
                    }
                    else if(uRolls[i]==5 && pAlive==2){
                        int alive=1;
                        Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        pButtons[alive].setVisible(true);
                        pButtons[alive].setDisable(false);
                        uRolls[i]-=1;
                        break;
                    }
                }
                if(uRolls[i]==6){
                    uActionCount-=1;
                    uAction=1;
                    if(uRolls[i]==6 && pAlive>2){
                    Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                    uAction=1;
                    int j=2;
                    int k=-2;
                    if(player_info[2][j]<=0){
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                    }
                    if(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                    }
                    pButtons[j].setVisible(true);
                    pButtons[j].setDisable(false);
                    pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                    pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                    uRolls[i]=-1;
                    break;
                    }
                    else if(uRolls[i]==6 && pAlive==2){
                        int alive=1;
                        Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        pButtons[alive].setVisible(true);
                        pButtons[alive].setDisable(false);
                        uRolls[i]=-1;
                        break;
                    }
                }
                if(uRolls[i]==7){
                    uAction=1;
                    if(uRolls[i]==7 && pAlive>2){
                    Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                    uAction=1;
                    int j=2;
                    int k=-2;
                    if(player_info[2][j]<=0){
                        while(player_info[2][j]<=0){
                            j+=1;
                        }
                    }
                    if(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                        while(player_info[2][(k+PlayerCount)%PlayerCount]<=0){
                            k-=1;
                        }
                    }
                    pButtons[j].setVisible(true);
                    pButtons[j].setDisable(false);
                    pButtons[(k+PlayerCount)%PlayerCount].setVisible(true);
                    pButtons[(k+PlayerCount)%PlayerCount].setDisable(false);
                    uRolls[i]-=1;
                    break;
                    }
                    else if(uRolls[i]==7 && pAlive==2){
                        int alive=1;
                        Infobox.setText(Infobox.getText()+"Click a player to shoot(red players are eligible to be shot)\n");
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        pButtons[alive].setVisible(true);
                        pButtons[alive].setDisable(false);
                        break;
                    }
                }
                if(uRolls[i]==8){
                    Infobox.setText(Infobox.getText()+"Click a player to heal(red players are eligible to be healed)\n");
                    uAction=2;
                    uActionCount-=1;
                    for(int j=0;j<PlayerCount;j++){
                        if(player_info[2][j]>0){
                            pButtons[j].setVisible(true);
                            pButtons[j].setDisable(false);
                        }
                    }
                    uRolls[i]=-1;
                    break;
                }
                if(uRolls[i]==9){
                    Infobox.setText(Infobox.getText()+"Click a player to heal(red players are eligible to be healed)\n");
                    uAction=2;
                    for(int j=0;j<PlayerCount;j++){
                        if(player_info[2][j]>0){
                            pButtons[j].setVisible(true);
                            pButtons[j].setDisable(false);
                        }
                    }
                    uRolls[i]-=1;
                    break;
                }
                if(uRolls[i]==10){
                    Infobox.setText(Infobox.getText()+"Click player to give duel dice to(red players eligible to pick)\n");
                    uAction=3;
                    uActionCount-=1;
                    for(int j=0;j<PlayerCount;j++){
                        if(player_info[2][j]>0){
                            pButtons[j].setVisible(true);
                            pButtons[j].setDisable(false);
                        }
                    }
                    break;
                }
            }
        }
        public void initial_turn_zombie(){
            uRolls=dice.roll(expansions,-1);
            uDynamiteCount=0;
            for(int i=0;i<3;i++){
                dButtons[i].setVisible(true);
                dButtons[i].setDisable(false);
            }
            for(int i=0;i<5;i++){
                if(uRolls[i]==1 && player_info[0][0]!=1){
                    dButtons[i].setStyle("-fx-background-color: RED");
                    dButtons[i].setOpacity(0.333);
                    dButtons[i].setDisable(true);
                    uDynamiteCount+=1;
                }
                else if(uRolls[i]==0){
                    dice.arrows(0);
                }
            }
            if(uDynamiteCount>=3){
                finalizeDiceAction();
            }
            EndTurn.setVisible(false);
            EndTurn.setDisable(true);  
        }
    }
    class AI{
        public void AI_Turn(int player){
            Infobox.setText("");
            int shot1shot2Count=0;
            pTurnL.setText("Player "+player+"'s Turn");
            int[]roll=dice.roll();
            for(int i=0;i<5;i++){
                if(roll[i]==0){
                    dice.arrows(player);
                }
            }
            int dynamite_count=0;
            for(int i=0;i<5;i++){
                if(roll[i]==1){
                    dynamite_count+=1;
                }
            }
            if(dynamite_count>=3){
                dice.dynamite(player);
            }
            for(int i=0;i<5;i++){
                int j=1;
                int k=1;
                if(roll[i]==2){
                    shot1shot2Count+=1;
                    if(pAlive>2 && player_info[2][(player+1)%PlayerCount]>0 && player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]>0){
                        AI_shots((player+1)%PlayerCount,((player-1)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+1)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                }
            }
            for(int i=0;i<5;i++){
                int j=2;
                int k=2;
                if(roll[i]==3){
                    shot1shot2Count+=1;
                    if(pAlive>2 && (player_info[2][((player+2)%PlayerCount)])>0 && (player_info[2][(((player-2)%PlayerCount)+PlayerCount)%PlayerCount])>0){
                        AI_shots((player+2)%PlayerCount,((player-2)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+2)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-2)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    } 
                }
            }
            for(int i=0;i<5;i++){
                if(roll[i]==4){
                    AI_beer(player);
                }
            }
            int gatling_count=0;
            for(int i=0;i<5;i++){
                if(roll[i]==5){
                    gatling_count+=1;
                }
            }
            if(gatling_count>=3){
                dice.gatling(player);
            }
            Infobox.setText(Infobox.getText()+"Press End Turn to go to next turn\n");
            if(player_info[0][player]==5 && shot1shot2Count==0){
                Infobox.setText("Suzy Lafayette uses her ability to gain 2 HP");
                dice.beer(pTurn);
                dice.beer(pTurn);
            }
            pTurn=(pTurn+1)%PlayerCount;
            while(player_info[2][pTurn]<=0){
                pTurn=(pTurn+1)%PlayerCount;
                }
        }
        public void AI_Turn(int player,boolean expansions){
            Random rand=new Random();
            int type=rand.nextInt(3);
            int[]rolls=new int[5];
            rolls=dice.roll(expansions,type);
            dice.show_dice(rolls);
            int shot1shot2Count=0;
            for(int i=0;i<5;i++){
                if(rolls[i]==0 || rolls[i]==10 || rolls[i]==16 || rolls[i]==22){
                    if(pcArrow==-1){
                        if(rand.nextInt(((ArrowPile-1)+ArrowPile)%ArrowPile)==0){
                            caPile.setVisible(false);
                            pcArrows[player].setVisible(true);
                            pcArrows[player].setImage(new Image("File:Pictures/Chief_Arrow.png"));
                            pcArrow=player;
                        }
                        else{
                            dice.arrows(player,expansions); 
                        }
                    }
                    else{
                        dice.arrows(player,expansions);
                    }
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==14){
                    dice.brokenarrow(player);
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==7){
                    dice.bullet(player);
                }
            }
            int dCount=0;
            for(int i=0;i<5;i++){
                if(rolls[i]==1 || rolls[i]==6 || rolls[i]==12 || rolls[i]==18){
                    dCount+=1;
                }
            }
            if(dCount>=3){
                dice.dynamite(player);
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==19){
                    dice.beer(player);
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==2 || rolls[i]==15){
                    shot1shot2Count+=1;
                    int j=1;
                    int k=1;
                    if(pAlive>2 && player_info[2][(player+1)%PlayerCount]>0 && player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]>0){
                        AI_shots((player+1)%PlayerCount,((player-1)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+1)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==8){
                    shot1shot2Count+=1;
                    int j=1;
                    int k=1;
                    if(pAlive>2 && player_info[2][(player+1)%PlayerCount]>0 && player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]>0){
                        AI_shots((player+1)%PlayerCount,((player-1)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+1)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                    j=1;
                    k=1;
                    if(pAlive>2 && player_info[2][(player+1)%PlayerCount]>0 && player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]>0){
                        AI_shots((player+1)%PlayerCount,((player-1)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+1)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==3){
                    shot1shot2Count+=1;
                    int j=2;
                    int k=-2;
                    if(pAlive>2 && (player_info[2][((player+2)%PlayerCount)])>0 && (player_info[2][(((player-2)%PlayerCount)+PlayerCount)%PlayerCount])>0){
                        AI_shots((player+2)%PlayerCount,((player-2)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+2)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-2)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    } 
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==9){
                    shot1shot2Count+=1;
                    int j=2;
                    int k=-2;
                    if(pAlive>2 && (player_info[2][((player+2)%PlayerCount)])>0 && (player_info[2][(((player-2)%PlayerCount)+PlayerCount)%PlayerCount])>0){
                        AI_shots((player+2)%PlayerCount,((player-2)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+2)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-2)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    } 
                    shot1shot2Count+=1;
                    j=2;
                    k=-2;
                    if(pAlive>2 && (player_info[2][((player+2)%PlayerCount)])>0 && (player_info[2][(((player-2)%PlayerCount)+PlayerCount)%PlayerCount])>0){
                        AI_shots((player+2)%PlayerCount,((player-2)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+2)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-2)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==4 || rolls[i]==17){
                    ai.AI_beer(player);
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==13){
                    ai.AI_beer(player);
                    ai.AI_beer(player);
                }
            }
            int gCount=0;
            for(int i=0;i<5;i++){
                if(rolls[i]==5 || rolls[i]==21){
                    gCount+=1;
                }
                if(rolls[i]==11){
                    gCount+=2;
                }
            }
            if(gCount>=3){
                dice.gatling(player);
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==23 || rolls[i]==20){
                    ai.AI_Duel(player);
                }
            }
        }
        public void AI_Human(int player){
            Random rand=new Random();
            int type=rand.nextInt(3);
            int[]rolls=new int[5];
            rolls=dice.roll(expansions,type);
            dice.show_dice(rolls);
            dice.show_dice(rolls);
            int shot1shot2Count=0;
            for(int i=0;i<5;i++){
                if(rolls[i]==0 || rolls[i]==10 || rolls[i]==16 || rolls[i]==22){
                    if(pcArrow==-1){
                        if(rand.nextInt(ArrowPile-1)==1){
                            caPile.setVisible(false);
                            pcArrows[player].setVisible(true);
                            pcArrows[player].setImage(new Image("File:Pictures/Chief_Arrow.png"));
                            pcArrow=player;
                        }
                    }
                    dice.arrows(player,expansions);
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==14){
                    dice.brokenarrow(player);
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==7){
                    dice.bullet(player);
                }
            }
            int dCount=0;
            for(int i=0;i<5;i++){
                if(rolls[i]==1 || rolls[i]==6 || rolls[i]==12 || rolls[i]==18){
                    dCount+=1;
                }
            }
            if(dCount>=3){
                dice.dynamite(player);
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==19){
                    dice.beer(player);
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==2 || rolls[i]==15){
                    shot1shot2Count+=1;
                    int j=1;
                    int k=1;
                    if(pAlive>2 && player_info[2][(player+1)%PlayerCount]>0 && player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]>0){
                        AI_shots((player+1)%PlayerCount,((player-1)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+1)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==8){
                    shot1shot2Count+=1;
                    int j=1;
                    int k=1;
                    if(pAlive>2 && player_info[2][(player+1)%PlayerCount]>0 && player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]>0){
                        AI_shots((player+1)%PlayerCount,((player-1)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+1)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                    j=1;
                    k=1;
                    if(pAlive>2 && player_info[2][(player+1)%PlayerCount]>0 && player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]>0){
                        AI_shots((player+1)%PlayerCount,((player-1)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+1)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==3){
                    shot1shot2Count+=1;
                    int j=2;
                    int k=-2;
                    if(pAlive>2 && (player_info[2][((player+2)%PlayerCount)])>0 && (player_info[2][(((player-2)%PlayerCount)+PlayerCount)%PlayerCount])>0){
                        AI_shots((player+2)%PlayerCount,((player-2)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+2)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-2)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    } 
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==9){
                    shot1shot2Count+=1;
                    int j=2;
                    int k=-2;
                    if(pAlive>2 && (player_info[2][((player+2)%PlayerCount)])>0 && (player_info[2][(((player-2)%PlayerCount)+PlayerCount)%PlayerCount])>0){
                        AI_shots((player+2)%PlayerCount,((player-2)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+2)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-2)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    } 
                    shot1shot2Count+=1;
                    j=2;
                    k=-2;
                    if(pAlive>2 && (player_info[2][((player+2)%PlayerCount)])>0 && (player_info[2][(((player-2)%PlayerCount)+PlayerCount)%PlayerCount])>0){
                        AI_shots((player+2)%PlayerCount,((player-2)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+2)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-2)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==4 || rolls[i]==17){
                    ai.AI_beer(player);
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==13){
                    ai.AI_beer(player);
                    ai.AI_beer(player);
                }
            }
            int gCount=0;
            for(int i=0;i<5;i++){
                if(rolls[i]==5 || rolls[i]==21){
                    gCount+=1;
                }
                if(rolls[i]==11){
                    gCount+=2;
                }
            }
            if(gCount>=3){
                dice.gatling(player);
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==23 || rolls[i]==20){
                    ai.AI_Duel(player);
                }
            }
        }
        public void AI_Zombie(int player){
            int[]rolls=new int[5];
            rolls=dice.roll(expansions,-1);
            dice.show_dice(rolls);
            for(int i=0;i<5;i++){
                if(rolls[i]==0){
                    dice.arrows(player,expansions);
                }
            }
            int dCount=0;
            for(int i=0;i<5;i++){
                if(rolls[i]==1){
                    dCount+=1;
                }
            }
            if(dCount>=3){
                dice.dynamite(player);
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==2){
                    int j=1;
                    int k=-1;
                    if(pAlive>2 && player_info[2][(player+1)%PlayerCount]>0 && player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]>0){
                        AI_shots_Zombie((player+1)%PlayerCount,((player-1)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+1)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-1)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots_Zombie((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                }
            }
            for(int i=0;i<5;i++){
                if(rolls[i]==3){
                    int j=2;
                    int k=-2;
                    if(pAlive>2 && (player_info[2][((player+2)%PlayerCount)])>0 && (player_info[2][(((player-2)%PlayerCount)+PlayerCount)%PlayerCount])>0){
                        AI_shots_Zombie((player+2)%PlayerCount,((player-2)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else if(pAlive>2){
                        if(player_info[2][(player+2)%PlayerCount]<=0){           
                            while(player_info[2][(player+j)%PlayerCount]<=0){
                                j+=1;
                            }
                        }
                        if(player_info[2][((player-2)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                            while(player_info[2][((player-k)%PlayerCount+PlayerCount)%PlayerCount]<=0){
                                k-=1;
                            }
                        }
                        AI_shots_Zombie((player+j)%PlayerCount,((player-k)%PlayerCount+PlayerCount)%PlayerCount,player);
                    }
                    else{
                        int alive=0;
                        while(player_info[2][alive]<=0){
                            alive+=1;
                        }
                        dice.shot(alive);
                    }
                }
            }
            int gCount=0;
            for(int i=0;i<5;i++){
                if(rolls[i]==5){
                    gCount+=1;
                }
            }
            if(gCount>=3){
                dice.gatling(player);
            }
        }
        private void AI_Duel(int player){
            Random rand=new Random();
            if(!Outbreak){
                if(player_info[1][player]==2){
                    dice.duel(pSheriff);
                }
                else{
                    int target=rand.nextInt(PlayerCount);
                    while(player_info[2][target]<=0 && target!=player){
                        target=rand.nextInt(PlayerCount);
                    }
                    dice.duel(target);
                }
            }
            else{
                int i=0;
                while(player_info[1][i]!=0 && i!=pZombieMaster){
                    i+=1;
                }
                dice.duel(i);
            }
        }
        private void AI_shots(int target1,int target2,int player){
            Random rand=new Random();
            int random_int;
            if(!Outbreak){
                if(player_info[1][player]==1){
                    random_int=rand.nextInt(2);
                    if(random_int==0){
                        dice.shot(target1);
                    }
                    else{
                        dice.shot(target2);
                    }
                }
                if(player_info[1][player]==2){
                    if(player_info[1][target1]==4){
                        dice.shot(target1);
                    }
                    else if(player_info[1][target2]==4){
                        dice.shot(target2);
                    }
                    else{
                       random_int=rand.nextInt(2);
                        if(random_int==0){
                            dice.shot(target1);
                        }
                        else{
                            dice.shot(target2);
                        } 
                    }
                }
                if(player_info[1][player]==3){
                    if(player_info[1][target1]==4){
                        dice.shot(target2);
                    }
                    else if(player_info[1][target2]==4){
                        dice.shot(target1);
                    }
                    else{
                       random_int=rand.nextInt(2);
                        if(random_int==0){
                            dice.shot(target1);
                        }
                        else{
                            dice.shot(target2);
                        } 
                    }
                }
                if(player_info[1][player]==4){
                    random_int=rand.nextInt(2);
                    if(random_int==0){
                        dice.shot(target1);
                    }
                    else{
                        dice.shot(target2);
                    }
                }
            }
            else{
                if(player_info[1][target1]==0 || target1==pZombieMaster){
                    dice.shot(target1);
                }
                else if(player_info[1][target2]==0 || target2==pZombieMaster){
                    dice.shot(target2);
                }
                else{
                    dice.shot(target1);
                }
            }
        }
        private void AI_beer(int player){
            if(player_info[1][player]==4){
                dice.beer(player);
            }
            else if(player_info[1][player]==3){
                dice.beer(pSheriff);
            }
            else if(player_info[1][player]==2){
                dice.beer(player);
            }
            else if(player_info[1][player]==1){
                dice.beer(player);
            }
        }
        private void AI_shots_Zombie(int target1,int target2,int player){
            if(player_info[1][target1]!=0 && target1!=pZombieMaster){
                dice.shot(target1);
            }
            else if(player_info[1][target2]!=0 && target2!=pZombieMaster){
                dice.shot(target2);
            }
            else{
                dice.shot(target1);
            }
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        pHP[0]=p0HP;pHP[1]=p1HP;pHP[2]=p2HP;pHP[3]=p3HP;pHP[4]=p4HP;pHP[5]=p5HP;pHP[6]=p6HP;pHP[7]=p7HP;
        pRoles[0]=p0Role;pRoles[1]=p1Role;pRoles[2]=p2Role;pRoles[3]=p3Role;pRoles[4]=p4Role;pRoles[5]=p5Role;pRoles[6]=p6Role;pRoles[7]=p7Role;
        pArrows[0]=p0Arrows;pArrows[1]=p1Arrows;pArrows[2]=p2Arrows;pArrows[3]=p3Arrows;pArrows[4]=p4Arrows;pArrows[5]=p5Arrows;pArrows[6]=p6Arrows;pArrows[7]=p7Arrows;
        pTags[0]=p0Tag; pTags[1]=p1Tag; pTags[2]=p2Tag; pTags[3]=p3Tag; pTags[4]=p4Tag; pTags[5]=p5Tag; pTags[6]=p6Tag; pTags[7]=p7Tag;
        pButtons[0]=p0Button;pButtons[1]=p1Button;pButtons[2]=p2Button;pButtons[3]=p3Button;pButtons[4]=p4Button;pButtons[5]=p5Button;pButtons[6]=p6Button;pButtons[7]=p7Button;
        pPics[0]=p0Pic;pPics[1]=p1Pic;pPics[2]=p2Pic;pPics[3]=p3Pic;pPics[4]=p4Pic;pPics[5]=p5Pic;pPics[6]=p6Pic;pPics[7]=p7Pic;
        dButtons[0]=d0Button;dButtons[1]=d1Button;dButtons[2]=d2Button;dButtons[3]=d3Button;dButtons[4]=d4Button;
        dPics[0]=d0Pic;dPics[1]=d1Pic;dPics[2]=d2Pic;dPics[3]=d3Pic;dPics[4]=d4Pic;
        pcArrows[0]=p0cArrow;pcArrows[1]=p1cArrow;pcArrows[2]=p2cArrow;pcArrows[3]=p3cArrow;pcArrows[4]=p4cArrow;pcArrows[5]=p5cArrow;pcArrows[6]=p6cArrow;pcArrows[7]=p7cArrow;
        dSwitch[0]=d0Switch;dSwitch[1]=d1Switch;dSwitch[2]=d2Switch;dSwitch[3]=d3Switch;dSwitch[4]=d4Switch;
        BoneyardCards[0]=0;BoneyardCards[1]=0;BoneyardCards[2]=1;BoneyardCards[3]=1;BoneyardCards[4]=1;BoneyardCards[5]=1;BoneyardCards[6]=1;BoneyardCards[7]=1;BoneyardCards[8]=2;BoneyardCards[9]=2;BoneyardCards[10]=2;
        GUIControl.GameDisappear();
        for(int i=0;i<5;i++){
            dSwitch[i].setVisible(false);
        }
        dice.roll(expansions,2);
    }       
}
